mkdir -p envs
python -m venv envs/starter-env
source `pwd`/envs/starter-env/bin/activate
